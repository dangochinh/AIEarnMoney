#!/usr/bin/env python3
"""
Educational Video Downloader Telegram Bot

A learning project to understand:
- Telegram bot development
- Video downloading and processing
- Async Python programming
- Platform APIs and streaming
"""

import logging
import asyncio
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

import config
from handlers import (
    start_command,
    help_command,
    cancel_command,
    handle_url,
)
from processors import cleanup_old_files

# Set up logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log the error and send a message to notify the developer"""
    logger.error(f"Update {update} caused error: {context.error}")

    if isinstance(update, Update) and update.message:
        await update.message.reply_text(
            '❌ An error occurred. Please try again later.'
        )


async def periodic_cleanup(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Periodically clean up old files"""
    logger.info("Running cleanup task...")
    await cleanup_old_files()
    logger.info("Cleanup completed")


async def post_init(application: Application) -> None:
    """Set up periodic tasks after bot is initialized"""
    # Schedule cleanup every 6 hours
    application.job_queue.run_repeating(
        periodic_cleanup,
        interval=6 * 3600,  # 6 hours
        first=10  # Start after 10 seconds
    )
    logger.info("Scheduled periodic cleanup task")


def main() -> None:
    """Start the bot"""
    # Validate configuration
    if not config.TELEGRAM_BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN not set!")
        return

    # Create bot application
    application = Application.builder().token(config.TELEGRAM_BOT_TOKEN).build()

    # Add handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("cancel", cancel_command))

    # Handle text messages (URLs)
    application.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_url)
    )

    # Error handler
    application.add_error_handler(error_handler)

    # Post-init callback
    application.post_init = post_init

    # Start the bot
    logger.info("Starting bot...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()
