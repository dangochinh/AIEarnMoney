from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional
import os


@dataclass
class VideoInfo:
    """Information about a downloaded video"""
    title: str
    file_path: str
    duration: Optional[int] = None
    format: Optional[str] = None
    size: Optional[int] = None


class BaseDownloader(ABC):
    """Abstract base class for platform-specific video downloaders"""

    def __init__(self, download_dir: str, quality: str = 'best'):
        self.download_dir = download_dir
        self.quality = quality

    @abstractmethod
    def can_handle(self, url: str) -> bool:
        """Check if this downloader can handle the given URL"""
        pass

    @abstractmethod
    async def download(self, url: str) -> VideoInfo:
        """Download a video and return metadata"""
        pass

    def _get_output_path(self, title: str, ext: str = 'mp4') -> str:
        """Generate a safe output file path"""
        # Sanitize filename
        safe_title = "".join(c for c in title if c.isalnum() or c in (' ', '-', '_')).rstrip()
        safe_title = safe_title[:100]  # Limit length

        output_path = os.path.join(self.download_dir, f"{safe_title}.{ext}")

        # Handle duplicate filenames
        if os.path.exists(output_path):
            counter = 1
            while os.path.exists(os.path.join(self.download_dir, f"{safe_title}_{counter}.{ext}")):
                counter += 1
            output_path = os.path.join(self.download_dir, f"{safe_title}_{counter}.{ext}")

        return output_path

    async def cleanup(self, file_path: str) -> None:
        """Remove downloaded file"""
        if os.path.exists(file_path):
            os.remove(file_path)
