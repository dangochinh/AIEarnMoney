import re
from .generic import GenericDownloader


class InstagramDownloader(GenericDownloader):
    """Instagram Reels/Posts — needs cookies.txt (export once from Brave extension)"""

    def can_handle(self, url: str) -> bool:
        patterns = [
            r'instagram\.com/reel/',
            r'instagram\.com/tv/',
            r'instagram\.com/p/',
            r'instagr\.am/',
        ]
        return any(re.search(p, url) for p in patterns)

    def _build_ydl_opts(self, url: str) -> dict:
        opts = super()._build_ydl_opts(url)
        opts.update({
            'format': 'best[ext=mp4]/best',
            'http_headers': {
                'User-Agent': (
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
                    'AppleWebKit/537.36 (KHTML, like Gecko) '
                    'Chrome/125.0.0.0 Safari/537.36'
                ),
            },
        })
        return opts
