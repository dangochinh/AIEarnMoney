import os
import yt_dlp
import asyncio
import concurrent.futures
from .base import BaseDownloader, VideoInfo
import config


class GenericDownloader(BaseDownloader):
    """Generic downloader using yt-dlp for any supported platform"""

    COOKIE_REQUIRED_DOMAINS = [
        'tiktok.com', 'douyin.com',
        'instagram.com', 'instagr.am',
        'facebook.com', 'fb.watch',
        'reddit.com', 'redd.it',
        'bilibili.com',
        'twitter.com', 'x.com',
    ]

    def can_handle(self, url: str) -> bool:
        return True

    def _needs_cookies(self, url: str) -> bool:
        return any(domain in url for domain in self.COOKIE_REQUIRED_DOMAINS)

    async def download(self, url: str) -> VideoInfo:
        loop = asyncio.get_event_loop()
        with concurrent.futures.ThreadPoolExecutor() as pool:
            try:
                future = loop.run_in_executor(pool, self._download_sync, url)
                return await asyncio.wait_for(future, timeout=config.DOWNLOAD_TIMEOUT)
            except asyncio.TimeoutError:
                raise Exception(f"Download timed out after {config.DOWNLOAD_TIMEOUT}s")
            except Exception as e:
                raise Exception(f"Failed to download video: {str(e)}")

    def _build_ydl_opts(self, url: str) -> dict:
        opts = {
            'format': self.quality,
            'outtmpl': os.path.join(self.download_dir, '%(title)s.%(ext)s'),
            'quiet': True,
            'no_warnings': True,
            'socket_timeout': config.REQUEST_TIMEOUT,
            'merge_output_format': 'mp4',
        }

        if self._needs_cookies(url):
            # Prefer pre-exported cookie file (no Keychain blocking)
            if os.path.exists(config.COOKIE_FILE) and os.path.getsize(config.COOKIE_FILE) > 100:
                opts['cookiefile'] = config.COOKIE_FILE
            elif config.COOKIE_BROWSER:
                # Fallback: live browser extraction (may trigger Keychain prompt)
                opts['cookiesfrombrowser'] = (config.COOKIE_BROWSER,)

        return opts

    def _download_sync(self, url: str) -> VideoInfo:
        ydl_opts = self._build_ydl_opts(url)

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)

            if info.get('_type') == 'playlist':
                info = info['entries'][0]

            file_path = ydl.prepare_filename(info)

            # Handle merged output format
            if not os.path.exists(file_path):
                mp4_path = os.path.splitext(file_path)[0] + '.mp4'
                if os.path.exists(mp4_path):
                    file_path = mp4_path

            return VideoInfo(
                title=info.get('title', 'video'),
                file_path=file_path,
                duration=info.get('duration'),
                format=info.get('ext'),
                size=os.path.getsize(file_path) if os.path.exists(file_path) else 0,
            )
