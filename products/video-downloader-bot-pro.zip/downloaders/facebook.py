import re
from .generic import GenericDownloader


class FacebookDownloader(GenericDownloader):
    """Facebook Reels / public videos — requires Brave cookies"""

    def can_handle(self, url: str) -> bool:
        patterns = [
            r'facebook\.com/watch',
            r'facebook\.com/reel/',
            r'facebook\.com/.*/videos/',
            r'fb\.watch/',
        ]
        return any(re.search(p, url) for p in patterns)

    def _build_ydl_opts(self, url: str) -> dict:
        opts = super()._build_ydl_opts(url)
        opts.update({
            'format': 'best[ext=mp4]/best',
        })
        return opts
