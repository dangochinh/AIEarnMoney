import re
from .generic import GenericDownloader


class TikTokDownloader(GenericDownloader):
    """TikTok / Douyin downloader — mobile headers bypass most IP blocks"""

    def can_handle(self, url: str) -> bool:
        patterns = [
            r'tiktok\.com/@.*?/video/',
            r'vt\.tiktok\.com/',
            r'vm\.tiktok\.com/',
            r'tiktok\.com/t/',
            r'douyin\.com/',
        ]
        return any(re.search(p, url) for p in patterns)

    def _build_ydl_opts(self, url: str) -> dict:
        opts = super()._build_ydl_opts(url)
        opts.update({
            'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
            'http_headers': {
                'User-Agent': (
                    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) '
                    'AppleWebKit/605.1.15 (KHTML, like Gecko) '
                    'Version/17.0 Mobile/15E148 Safari/604.1'
                ),
                'Referer': 'https://www.tiktok.com/',
            },
            'extractor_args': {
                'tiktok': {
                    'api_hostname': ['api22-normal-c-useast2a.tiktokv.com'],
                    'app_name': ['tiktok_web'],
                },
            },
        })
        return opts
