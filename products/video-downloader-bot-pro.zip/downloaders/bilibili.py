import re
from .generic import GenericDownloader


class BilibiliDownloader(GenericDownloader):
    """Bilibili downloader — requires browser-like User-Agent to bypass 412"""

    def can_handle(self, url: str) -> bool:
        return bool(re.search(r'bilibili\.com/video/', url))

    def _build_ydl_opts(self, url: str) -> dict:
        opts = super()._build_ydl_opts(url)
        opts.update({
            'format': 'bestvideo[ext=mp4]+bestaudio/best[ext=mp4]/best',
            'http_headers': {
                'User-Agent': (
                    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
                    'AppleWebKit/537.36 (KHTML, like Gecko) '
                    'Chrome/125.0.0.0 Safari/537.36'
                ),
                'Referer': 'https://www.bilibili.com/',
            },
        })
        return opts
