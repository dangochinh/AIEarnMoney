import re
import asyncio
from .generic import GenericDownloader


class YouTubeDownloader(GenericDownloader):
    """Specialized downloader for YouTube videos"""

    def can_handle(self, url: str) -> bool:
        """Check if URL is a YouTube video"""
        youtube_patterns = [
            r'youtube\.com/watch\?v=',
            r'youtu\.be/',
            r'youtube\.com/shorts/',
        ]
        return any(re.search(pattern, url) for pattern in youtube_patterns)

    async def download(self, url: str):
        """Download YouTube video with MP4 format preference"""
        # Override quality for better YouTube support
        original_quality = self.quality
        self.quality = 'best[ext=mp4]/best'

        try:
            return await super().download(url)
        finally:
            self.quality = original_quality
