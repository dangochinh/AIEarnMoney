# Video Downloader Bot - Educational Project

A Telegram bot for downloading videos from various platforms. This is an **educational project** designed to learn about:

- 🤖 Telegram bot development with `python-telegram-bot`
- 📥 Video downloading using `yt-dlp`
- 🔄 Async Python programming with `asyncio`
- 🎬 Video processing with `ffmpeg`
- 📋 Project architecture and design patterns

## ⚠️ Important Legal Note

This project is **for educational purposes only**. When using this bot:

1. **Respect Copyright**: Only download content you have the right to download
2. **Follow Terms of Service**: Each platform has ToS that may prohibit automated downloads
3. **Use Responsibly**: Don't distribute downloaded content without permission
4. **Attribution**: Always credit original creators if you share content

## 🚀 Quick Start

### Prerequisites

- Python 3.9+
- FFmpeg (for video processing)
- A Telegram bot token (from BotFather)

### Installation

1. **Clone/Create the project:**
```bash
cd video_downloader_bot
```

2. **Create virtual environment:**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies:**
```bash
pip install -r requirements.txt
```

4. **Install FFmpeg:**
```bash
# macOS
brew install ffmpeg

# Ubuntu/Debian
sudo apt-get install ffmpeg

# Windows (using chocolatey)
choco install ffmpeg
```

5. **Set up environment variables:**
```bash
cp .env.example .env
# Edit .env and add your TELEGRAM_BOT_TOKEN
```

### Running the Bot

```bash
python main.py
```

The bot will start polling for messages from Telegram.

## 📖 Usage

### Commands

- `/start` - Welcome message and overview
- `/help` - Show available commands and usage
- `/cancel` - Cancel current operation

### How to Use

1. Send a video URL to the bot
2. The bot will download it
3. The bot will send you the downloaded video
4. Videos are automatically deleted after 24 hours

### Supported Platforms

The bot supports downloading from:
- YouTube & YouTube Shorts
- TikTok & Douyin
- Instagram Reels & Posts
- Facebook videos
- Bilibili
- And 500+ other platforms (via yt-dlp)

## 🏗️ Project Structure

```
video_downloader_bot/
├── main.py                    # Entry point, bot setup
├── config.py                  # Configuration management
├── requirements.txt           # Python dependencies
├── .env.example              # Environment variables template
├── handlers/                 # Telegram message handlers
│   ├── download.py          # Core download logic
│   ├── start.py             # Command handlers
│   └── __init__.py
├── downloaders/             # Platform-specific downloaders
│   ├── base.py              # Abstract base class
│   ├── youtube.py           # YouTube handler
│   ├── tiktok.py            # TikTok handler
│   ├── instagram.py         # Instagram handler
│   ├── generic.py           # Fallback using yt-dlp
│   └── __init__.py
├── processors/              # Video processing
│   ├── video.py             # FFmpeg wrapper
│   ├── utils.py             # File utilities
│   └── __init__.py
└── tests/                   # Test files
    └── test_downloaders.py
```

## 🎓 Learning Outcomes

By building and studying this project, you'll learn:

1. **Telegram Bot Development**
   - Using `python-telegram-bot` library
   - Handling commands and messages
   - Sending files back to users

2. **Video Downloading**
   - Using yt-dlp for multiple platforms
   - Platform-specific handling
   - Error handling and retries

3. **Async Python**
   - `asyncio` for non-blocking operations
   - Running CPU-intensive tasks in threads
   - Proper async/await patterns

4. **Video Processing**
   - FFmpeg integration
   - Watermark removal (advanced topic)
   - Video metadata extraction

5. **Project Architecture**
   - Design patterns (Strategy, Factory)
   - Configuration management
   - Error handling and logging
   - File management and cleanup

## 🔧 Configuration

Edit `.env` to customize:

```ini
# Telegram
TELEGRAM_BOT_TOKEN=your_token_here

# Storage
DOWNLOAD_DIR=/tmp/video_downloads
MAX_FILE_SIZE=100  # MB
CLEANUP_HOURS=24   # Auto-delete files older than this

# Processing
ENABLE_WATERMARK_REMOVAL=false
VIDEO_FORMAT=best[ext=mp4]/best
REQUEST_TIMEOUT=30
```

## 📝 Key Features

### 1. Multiple Downloader Classes
- **YouTubeDownloader**: Optimized for YouTube videos
- **TikTokDownloader**: Handles TikTok URLs
- **InstagramDownloader**: Processes Instagram content
- **GenericDownloader**: Fallback for other platforms

### 2. Async Design
- Non-blocking file downloads
- Concurrent user handling
- Proper resource management

### 3. Error Handling
- Network error recovery
- File size validation
- Disk space checking
- User-friendly error messages

### 4. Automatic Cleanup
- Removes old files automatically
- Configurable retention period
- Prevents disk space issues

## 🚀 Advanced Usage

### Deploying to a Server

**Using systemd (Linux):**
```bash
# Create service file
sudo nano /etc/systemd/system/video-bot.service

[Unit]
Description=Video Downloader Bot
After=network.target

[Service]
Type=simple
User=your_user
WorkingDirectory=/path/to/video_downloader_bot
ExecStart=/path/to/video_downloader_bot/venv/bin/python main.py
Restart=always
Environment="PYTHONUNBUFFERED=1"

[Install]
WantedBy=multi-user.target
```

**Start service:**
```bash
sudo systemctl start video-bot
sudo systemctl enable video-bot
```

### Using Webhooks Instead of Polling

Modify `main.py` to use webhooks for production:
```python
application.run_webhook(
    listen="0.0.0.0",
    port=8080,
    url_path="/bot",
    webhook_url="https://your-domain.com/bot"
)
```

## 🧪 Testing

```bash
# Run tests
python -m pytest tests/

# Test a specific URL
python -c "
from handlers.download import DownloadManager
import asyncio

async def test():
    manager = DownloadManager()
    result = await manager.download_video('https://www.youtube.com/watch?v=dQw4w9WgXcQ')
    print(result)

asyncio.run(test())
"
```

## 📚 Related Learning Resources

- [python-telegram-bot Documentation](https://docs.python-telegram-bot.org/)
- [yt-dlp Documentation](https://github.com/yt-dlp/yt-dlp)
- [FFmpeg Documentation](https://ffmpeg.org/documentation.html)
- [Python asyncio Guide](https://docs.python.org/3/library/asyncio.html)

## ⚡ Performance Tips

1. **Use a VPS** instead of local machine for 24/7 operation
2. **Set up logging** to monitor bot health
3. **Implement rate limiting** to prevent abuse
4. **Use Redis** for caching if scaling up
5. **Monitor disk space** on your server

## 🐛 Troubleshooting

**Bot doesn't respond:**
- Check `TELEGRAM_BOT_TOKEN` is correct
- Verify network connection
- Check logs: `python main.py 2>&1 | tee bot.log`

**Download fails:**
- Check if URL is supported by yt-dlp
- Verify FFmpeg is installed: `ffmpeg -version`
- Check disk space: `df -h`

**File too large:**
- Increase `MAX_FILE_SIZE` in `.env`
- Or download from different platform (different quality)

**Telegram API errors:**
- Check rate limits
- Implement retry logic
- Use exponential backoff

## 📄 License

This is an educational project. Use it to learn and teach others about Python, APIs, and bot development.

## 💡 Future Enhancements

Ideas for extending this project:

- [ ] User preferences database (quality, format)
- [ ] Download history tracking
- [ ] Rate limiting per user
- [ ] Batch download from playlists
- [ ] Video format/quality selection UI
- [ ] Admin dashboard
- [ ] Integration with more platforms
- [ ] Advanced watermark detection & removal
- [ ] Video preview generation
- [ ] Web interface

---

**Happy Learning! 🎓** Feel free to fork, modify, and use this project for education!
