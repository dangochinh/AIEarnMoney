# Setup Guide - Video Downloader Bot

This guide will walk you through setting up the educational video downloader Telegram bot.

## Step 1: Prerequisites

Make sure you have:
- **Python 3.9 or higher** - [Download](https://www.python.org/downloads/)
- **FFmpeg** - For video processing
- **Git** (optional) - For cloning/managing the project
- **A Telegram Account** - To create a bot

## Step 2: Install FFmpeg

### macOS
```bash
brew install ffmpeg
```

### Ubuntu/Debian
```bash
sudo apt-get update
sudo apt-get install ffmpeg
```

### Windows
Download from [ffmpeg.org](https://ffmpeg.org/download.html) or use:
```bash
choco install ffmpeg
```

Verify installation:
```bash
ffmpeg -version
```

## Step 3: Create a Telegram Bot

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Follow the prompts:
   - Give your bot a name (e.g., "My Video Downloader")
   - Give your bot a username (must end with `_bot`, e.g., `my_video_downloader_bot`)
4. Copy the bot token (looks like `123456789:ABCdefGHIjklmnoPQRstuvWXYZabcdefg`)
5. Save this token - you'll need it in Step 6

## Step 4: Project Setup

### Option A: From Directory
```bash
# Navigate to project directory
cd video_downloader_bot

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
# venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Option B: Fresh Installation
```bash
# Create project directory
mkdir video_downloader_bot
cd video_downloader_bot

# Initialize git (optional)
git init

# Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Create requirements.txt with this content:
cat > requirements.txt << EOF
python-telegram-bot[all]==21.3
yt-dlp==2024.12.10
ffmpeg-python==0.2.1
python-dotenv==1.0.1
aiofiles==23.2.1
EOF

# Install dependencies
pip install -r requirements.txt
```

## Step 5: Configure Environment Variables

Create a `.env` file in the project root:

```bash
cp .env.example .env
```

Edit `.env` and add your bot token:

```ini
TELEGRAM_BOT_TOKEN=your_bot_token_here
DOWNLOAD_DIR=/tmp/video_downloads
MAX_FILE_SIZE=100
CLEANUP_HOURS=24
ENABLE_WATERMARK_REMOVAL=false
VIDEO_FORMAT=best[ext=mp4]/best
REQUEST_TIMEOUT=30
```

Replace `your_bot_token_here` with the token from Step 3.

## Step 6: Project Structure

Ensure your project has this structure:

```
video_downloader_bot/
├── main.py
├── config.py
├── requirements.txt
├── .env
├── .env.example
├── README.md
├── SETUP.md
├── handlers/
│   ├── __init__.py
│   ├── download.py
│   └── start.py
├── downloaders/
│   ├── __init__.py
│   ├── base.py
│   ├── youtube.py
│   ├── tiktok.py
│   ├── instagram.py
│   └── generic.py
├── processors/
│   ├── __init__.py
│   ├── video.py
│   └── utils.py
└── tests/
    ├── __init__.py
    └── test_downloaders.py
```

## Step 7: Run the Bot

```bash
# Make sure virtual environment is activated
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Start the bot
python main.py
```

You should see:
```
Starting bot...
```

The bot is now running! 🚀

## Step 8: Test the Bot

1. Open Telegram
2. Search for your bot (the username from Step 3)
3. Send `/start`
4. Send a video URL (e.g., YouTube link)

The bot should:
1. Accept the URL
2. Download the video
3. Send it back to you in the chat

## Troubleshooting

### "ModuleNotFoundError: No module named 'telegram'"
```bash
# Make sure virtual environment is activated
source venv/bin/activate  # or venv\Scripts\activate

# Reinstall requirements
pip install -r requirements.txt
```

### "TELEGRAM_BOT_TOKEN not set!"
1. Check `.env` file exists
2. Verify `TELEGRAM_BOT_TOKEN=...` is in `.env`
3. Make sure you're in the correct directory when running

### FFmpeg not found
1. Verify FFmpeg is installed: `ffmpeg -version`
2. If not installed, follow Step 2 again
3. Restart your terminal after installing

### "Permission denied" on macOS/Linux
```bash
chmod +x main.py
python main.py
```

### Bot not responding in Telegram
1. Check that `main.py` is running (you should see "Starting bot...")
2. Check the bot token in `.env` is correct
3. Try restarting the bot (Ctrl+C then `python main.py`)

### Download fails
1. Check the URL is valid and accessible
2. Check you have internet connection
3. Check disk space: `df -h` (Unix) or `dir` (Windows)
4. Check video isn't too large (default: 100 MB)

## Next Steps

Once the bot is running:

1. **Customize Configuration** - Edit `.env` to adjust settings
2. **Add Features** - Modify handlers to add new commands
3. **Deploy** - Run on a server for 24/7 operation
4. **Learn** - Study the code to understand async Python and APIs

## Learning Resources

- [python-telegram-bot Docs](https://docs.python-telegram-bot.org/)
- [yt-dlp Documentation](https://github.com/yt-dlp/yt-dlp)
- [Python asyncio Tutorial](https://docs.python.org/3/library/asyncio.html)
- [FFmpeg Guide](https://ffmpeg.org/documentation.html)

## What You're Learning

This project teaches:
- 🤖 **Bot Development**: How to create Telegram bots
- 📥 **Video Downloading**: Using APIs and yt-dlp
- 🔄 **Async Programming**: Non-blocking code with asyncio
- 🏗️ **Architecture**: Designing modular Python applications
- 📋 **Best Practices**: Error handling, logging, configuration

## Deployment (Optional)

To run 24/7 on a server:

### Using a VPS (DigitalOcean, Linode, AWS)
1. SSH into your VPS
2. Follow steps 1-7 on the server
3. Install `screen` or `tmux`
4. Run in screen: `screen python main.py`

### Using systemd (Linux)
See README.md for systemd service setup

### Using Docker
Create a `Dockerfile`:
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN apt-get update && apt-get install -y ffmpeg
RUN pip install -r requirements.txt

COPY . .

CMD ["python", "main.py"]
```

Run:
```bash
docker build -t video-bot .
docker run -e TELEGRAM_BOT_TOKEN=your_token video-bot
```

## Questions?

If you have issues:
1. Check error messages carefully
2. Review relevant documentation
3. Check the code comments for explanations
4. Try simplifying - test with basic URLs first

Happy learning! 🎓
