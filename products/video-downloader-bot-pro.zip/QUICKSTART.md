# Quick Start - Video Downloader Bot

Get up and running in 5 minutes! 🚀

## TL;DR

```bash
# 1. Install FFmpeg (one-time)
brew install ffmpeg  # or apt-get install ffmpeg on Ubuntu

# 2. Setup project
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3. Configure bot
# Get token from @BotFather on Telegram
cp .env.example .env
# Edit .env and add TELEGRAM_BOT_TOKEN=your_token

# 4. Run
python main.py

# 5. Test
# Send a video URL to your bot on Telegram!
```

## Detailed Steps

### 1. Get Your Bot Token (2 min)

1. Open Telegram
2. Search for **@BotFather**
3. Send `/newbot`
4. Create your bot (choose a name and username)
5. Copy the token that looks like: `123456789:ABCdefGHIjklmnoPQRstuvWXYZ...`

### 2. Install System Dependencies (3 min)

**macOS:**
```bash
brew install ffmpeg
```

**Ubuntu/Debian:**
```bash
sudo apt-get update && sudo apt-get install ffmpeg
```

**Windows:** Download from [ffmpeg.org](https://ffmpeg.org/download.html)

Verify:
```bash
ffmpeg -version
```

### 3. Setup Python Project (2 min)

```bash
# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate  # macOS/Linux
# OR
venv\Scripts\activate  # Windows

# Install Python packages
pip install -r requirements.txt
```

### 4. Configure Bot (1 min)

```bash
# Copy example config
cp .env.example .env

# Edit .env - add your token
nano .env
# or use your favorite editor
# Find this line and replace:
# TELEGRAM_BOT_TOKEN=your_token_here
```

### 5. Run Bot (< 1 min)

```bash
python main.py
```

You should see:
```
Starting bot...
```

### 6. Test It!

1. Open Telegram
2. Find your bot (search by the username you created)
3. Send `/start` to see welcome message
4. Send any video URL:
   ```
   https://www.youtube.com/watch?v=dQw4w9WgXcQ
   ```
5. Bot downloads and sends it back! ✅

## Supported URLs

- **YouTube**: youtube.com, youtu.be, youtube.com/shorts
- **TikTok**: tiktok.com, vm.tiktok.com, vt.tiktok.com
- **Instagram**: instagram.com/reel, instagram.com/tv
- **And 500+ more** (via yt-dlp)

## Common Issues

| Issue | Fix |
|-------|-----|
| `ModuleNotFoundError` | Activate venv: `source venv/bin/activate` |
| `TELEGRAM_BOT_TOKEN not set` | Check `.env` file exists and has your token |
| `ffmpeg: command not found` | Install FFmpeg (Step 2) and restart terminal |
| Bot doesn't respond | Check `python main.py` is running without errors |

## Next Steps

- 📖 Read [README.md](README.md) for full documentation
- 🔧 Customize [config.py](config.py) settings
- 🧪 Run tests: `python -m pytest tests/`
- 🚀 [Deploy](README.md#deploying-to-a-server) on a server

## What You Can Learn

- **Telegram Bot API** - Real-world bot development
- **Async Python** - Non-blocking async/await code
- **Video APIs** - How platforms deliver content
- **Project Architecture** - Modular design patterns

---

**Stuck?** Check [SETUP.md](SETUP.md) for detailed troubleshooting.

**Questions about the code?** Each file has helpful comments explaining the design.

**Want to understand more?** Read the docstrings:
```bash
python -c "from handlers.download import DownloadManager; help(DownloadManager)"
```

Happy learning! 🎓
