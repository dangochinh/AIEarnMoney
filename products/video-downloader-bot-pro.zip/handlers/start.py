from telegram import Update
from telegram.ext import ContextTypes


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /start command"""
    welcome_message = """
🎬 Welcome to Video Downloader Bot!

This is an educational tool to learn about video downloading, APIs, and async programming.

📺 **Supported Platforms:**
• YouTube & YouTube Shorts
• TikTok & Douyin
• Instagram Reels & Posts
• Facebook videos
• Bilibili
• And many more platforms supported by yt-dlp

📝 **How to use:**
1. Just send me a video URL
2. I'll download it and send it back to you
3. Videos will be deleted after 24 hours

⚠️ **Important Legal Note:**
This bot is for educational purposes only. Please respect copyright laws and platform Terms of Service. Only download content you have permission to download.

📚 **Learn:**
- Video downloading & processing
- Platform APIs & streaming
- Async Python programming
- File management & cleanup

Type /help for more commands.
    """
    await update.message.reply_text(welcome_message)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /help command"""
    help_message = """
📖 **Commands:**
/start - Show welcome message
/help - Show this help message
/cancel - Cancel current operation

**Usage:**
Send any video URL and I'll download it for you.

**Example URLs:**
• https://www.youtube.com/watch?v=dQw4w9WgXcQ
• https://vm.tiktok.com/...
• https://www.instagram.com/reel/...

**Limitations:**
• Max file size: 100 MB
• Free tier: 50 videos/day (configurable)
• Files cleanup: 24 hours (configurable)
• Educational use only

Have fun learning! 🚀
    """
    await update.message.reply_text(help_message)


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /cancel command"""
    await update.message.reply_text('✅ Cancelled. Feel free to send another video URL!')
