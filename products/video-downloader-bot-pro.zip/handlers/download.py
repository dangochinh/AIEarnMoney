import config
from downloaders import (
    YouTubeDownloader,
    TikTokDownloader,
    InstagramDownloader,
    FacebookDownloader,
    BilibiliDownloader,
    GenericDownloader,
)
from processors import (
    VideoProcessor,
    format_file_size,
    format_duration,
    check_disk_space,
    is_file_too_large,
)
from telegram import Update
from telegram.ext import ContextTypes
import logging

logger = logging.getLogger(__name__)


class DownloadManager:
    """Manages video downloads and coordinates downloaders"""

    def __init__(self):
        self.downloaders = [
            YouTubeDownloader(config.DOWNLOAD_DIR),
            TikTokDownloader(config.DOWNLOAD_DIR),
            InstagramDownloader(config.DOWNLOAD_DIR),
            FacebookDownloader(config.DOWNLOAD_DIR),
            BilibiliDownloader(config.DOWNLOAD_DIR),
            GenericDownloader(config.DOWNLOAD_DIR),
        ]
        self.processor = VideoProcessor(config.ENABLE_WATERMARK_REMOVAL)

    async def download_video(self, url: str) -> dict:
        """
        Download a video from given URL using appropriate downloader.

        Returns:
            Dictionary with keys:
            - 'success': bool
            - 'file_path': str (if successful)
            - 'title': str (if successful)
            - 'error': str (if failed)
            - 'message': str (status message)
        """
        # Check disk space
        if not await check_disk_space(50):
            return {
                'success': False,
                'error': 'Not enough disk space',
                'message': '❌ Not enough disk space available'
            }

        # Find appropriate downloader
        downloader = None
        for dl in self.downloaders:
            if dl.can_handle(url):
                downloader = dl
                break

        if not downloader:
            return {
                'success': False,
                'error': 'Unsupported URL',
                'message': '❌ This URL is not supported'
            }

        try:
            logger.info(f"Starting download from {downloader.__class__.__name__}: {url}")

            # Download video
            video_info = await downloader.download(url)

            # Check file size
            if await is_file_too_large(video_info.file_path):
                await downloader.cleanup(video_info.file_path)
                return {
                    'success': False,
                    'error': 'File too large',
                    'message': f'❌ File is too large ({format_file_size(video_info.size)} > {format_file_size(config.MAX_FILE_SIZE)})'
                }

            # Build response
            message_parts = [
                '✅ Download successful!',
                f'📝 Title: {video_info.title}',
                f'📦 Size: {format_file_size(video_info.size)}',
            ]

            if video_info.duration:
                message_parts.append(f'⏱️ Duration: {format_duration(video_info.duration)}')

            return {
                'success': True,
                'file_path': video_info.file_path,
                'title': video_info.title,
                'size': video_info.size,
                'message': '\n'.join(message_parts)
            }

        except Exception as e:
            logger.error(f"Download failed: {e}")
            return {
                'success': False,
                'error': str(e),
                'message': f'❌ Download failed: {str(e)}'
            }


async def handle_url(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle incoming URL messages"""
    message_text = update.message.text
    manager = DownloadManager()

    try:
        # Validate URL format
        if not (message_text.startswith('http://') or message_text.startswith('https://')):
            await update.message.reply_text(
                '❌ Please send a valid URL (starting with http:// or https://)'
            )
            return

        # Send downloading status
        status_msg = await update.message.reply_text('⏳ Downloading video...')

        # Download video
        result = await manager.download_video(message_text)

        # Update status message
        await status_msg.edit_text(result['message'])

        # Send video file if successful
        if result['success']:
            try:
                with open(result['file_path'], 'rb') as video_file:
                    await update.message.reply_video(
                        video_file,
                        caption=f"Title: {result['title']}\nSize: {format_file_size(result['size'])}"
                    )
                # Cleanup after sending
                await manager.downloaders[0].cleanup(result['file_path'])
            except Exception as e:
                logger.error(f"Error sending video: {e}")
                await update.message.reply_text(
                    f'❌ Error sending video: {str(e)}'
                )

    except Exception as e:
        logger.error(f"Error in handle_url: {e}")
        await update.message.reply_text(
            f'❌ An error occurred: {str(e)}'
        )
