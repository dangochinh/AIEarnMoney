#!/usr/bin/env python3
"""
Export Brave cookies to Netscape-format cookies.txt without Keychain blocking.
Uses pycookiecheat to decrypt cookies directly from SQLite DB.
Run: python3 export_cookies.py
"""
import os
import sys
import shutil
import sqlite3
import tempfile

COOKIE_FILE = os.path.join(os.path.dirname(__file__), 'cookies.txt')
BRAVE_DB = os.path.expanduser(
    '~/Library/Application Support/BraveSoftware/Brave-Browser/Default/Cookies'
)

TARGET_DOMAINS = [
    'tiktok.com', 'douyin.com',
    'instagram.com',
    'facebook.com',
    'bilibili.com',
    'twitter.com', 'x.com',
    'reddit.com',
]


def export_cookies_direct():
    """Copy Brave DB and read cookies without triggering Keychain."""
    if not os.path.exists(BRAVE_DB):
        print("❌ Brave cookie DB not found")
        sys.exit(1)

    try:
        from pycookiecheat import chrome_cookies
    except ImportError:
        print("❌ pycookiecheat not installed. Run: pip install pycookiecheat")
        sys.exit(1)

    print(f"Reading cookies from Brave DB...")

    lines = ["# Netscape HTTP Cookie File"]
    total = 0

    # Copy DB to temp to avoid SQLite lock issues while Brave is open
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
        tmp_path = tmp.name

    try:
        shutil.copy2(BRAVE_DB, tmp_path)

        conn = sqlite3.connect(tmp_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Get all cookies for our target domains (encrypted values skipped for now)
        cur.execute("""
            SELECT host_key, path, is_secure, expires_utc, name, value, encrypted_value
            FROM cookies
            ORDER BY host_key
        """)

        rows = cur.fetchall()
        conn.close()

        # Try to decrypt using pycookiecheat
        try:
            # Get decryption cookies via pycookiecheat for target domains
            all_decrypted = {}
            for domain in TARGET_DOMAINS:
                try:
                    cookies = chrome_cookies(f'https://{domain}', browser='brave')
                    all_decrypted[domain] = cookies
                    print(f"  ✅ {domain}: {len(cookies)} cookies")
                except Exception:
                    print(f"  ⚠️  {domain}: decryption skipped")

        except Exception as e:
            print(f"⚠️  pycookiecheat: {e}")
            all_decrypted = {}

        # Write Netscape format
        written = 0
        for domain, cookies in all_decrypted.items():
            for name, value in cookies.items():
                # Simple format — host, include_subdomains, path, secure, expiry, name, value
                host = f'.{domain}' if not domain.startswith('.') else domain
                line = f"{host}\tTRUE\t/\tFALSE\t2147483647\t{name}\t{value}"
                lines.append(line)
                written += 1

        if written > 0:
            with open(COOKIE_FILE, 'w') as f:
                f.write('\n'.join(lines) + '\n')
            print(f"\n✅ Exported {written} cookies → {COOKIE_FILE}")
            return True
        else:
            print("\n⚠️  No cookies decrypted. Falling back to yt-dlp method...")
            return False

    finally:
        os.unlink(tmp_path)


def export_via_ytdlp():
    """Fallback: use yt-dlp's built-in extraction (requires Keychain approval)."""
    import yt_dlp
    print("\nFalling back to yt-dlp cookie extraction...")
    print("⚠️  macOS may prompt for Keychain access — click 'Allow'")

    opts = {
        'cookiesfrombrowser': ('brave',),
        'cookiefile': COOKIE_FILE,
        'skip_download': True,
        'quiet': True,
        'no_warnings': True,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.extract_info('https://www.tiktok.com/', download=False)
        size = os.path.getsize(COOKIE_FILE) if os.path.exists(COOKIE_FILE) else 0
        if size > 100:
            print(f"✅ Exported via yt-dlp ({size // 1024} KB)")
            return True
        return False
    except Exception as e:
        print(f"❌ yt-dlp fallback failed: {e}")
        return False


if __name__ == '__main__':
    success = export_cookies_direct()
    if not success:
        success = export_via_ytdlp()

    if success:
        print("\n🎉 Cookie file ready. Bot will use this file for authenticated platforms.")
    else:
        print("\n❌ Cookie export failed. TikTok/Instagram may not work.")
        sys.exit(1)
