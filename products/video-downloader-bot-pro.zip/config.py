import os
from dotenv import load_dotenv

load_dotenv()

# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
if not TELEGRAM_BOT_TOKEN:
    raise ValueError("TELEGRAM_BOT_TOKEN environment variable is not set")

# Download Configuration
DOWNLOAD_DIR = os.getenv('DOWNLOAD_DIR', '/tmp/video_downloads')
MAX_FILE_SIZE = int(os.getenv('MAX_FILE_SIZE', 100)) * 1024 * 1024  # 100 MB default
CLEANUP_HOURS = int(os.getenv('CLEANUP_HOURS', 24))

# Video Quality
DEFAULT_VIDEO_FORMAT = os.getenv('VIDEO_FORMAT', 'best[ext=mp4]/best')

# Platform-specific
ENABLE_WATERMARK_REMOVAL = os.getenv('ENABLE_WATERMARK_REMOVAL', 'false').lower() == 'true'
REQUEST_TIMEOUT = int(os.getenv('REQUEST_TIMEOUT', 30))

# Cookie source: 'brave', 'chrome', 'firefox', 'safari', or None to disable
COOKIE_BROWSER = os.getenv('COOKIE_BROWSER', 'brave')

# Path to exported cookie file (faster than live browser extraction)
_cookies_full = os.path.join(os.path.dirname(__file__), 'cookies_full.txt')
_cookies_basic = os.path.join(os.path.dirname(__file__), 'cookies.txt')
COOKIE_FILE = _cookies_full if os.path.exists(_cookies_full) else _cookies_basic

# Download timeout in seconds (prevents hanging on cookie extraction)
DOWNLOAD_TIMEOUT = int(os.getenv('DOWNLOAD_TIMEOUT', 60))

# Create download directory if it doesn't exist
os.makedirs(DOWNLOAD_DIR, exist_ok=True)
