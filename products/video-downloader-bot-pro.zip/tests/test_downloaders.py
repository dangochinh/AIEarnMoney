"""
Tests for video downloaders

This demonstrates how to test the downloading functionality.
Run with: python -m pytest tests/test_downloaders.py -v
"""

import pytest
import sys
import os
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from downloaders import (
    YouTubeDownloader,
    TikTokDownloader,
    InstagramDownloader,
    GenericDownloader,
)


class TestDownloaderURLDetection:
    """Test platform detection for different downloaders"""

    def test_youtube_downloader_detection(self):
        """Test that YouTubeDownloader detects YouTube URLs"""
        yt = YouTubeDownloader('/tmp')

        assert yt.can_handle('https://www.youtube.com/watch?v=dQw4w9WgXcQ')
        assert yt.can_handle('https://youtu.be/dQw4w9WgXcQ')
        assert yt.can_handle('https://www.youtube.com/shorts/dQw4w9WgXcQ')

    def test_youtube_downloader_rejection(self):
        """Test that YouTubeDownloader rejects non-YouTube URLs"""
        yt = YouTubeDownloader('/tmp')

        assert not yt.can_handle('https://www.tiktok.com/video/123')
        assert not yt.can_handle('https://www.instagram.com/reel/123')

    def test_tiktok_downloader_detection(self):
        """Test that TikTokDownloader detects TikTok URLs"""
        tt = TikTokDownloader('/tmp')

        assert tt.can_handle('https://www.tiktok.com/@user/video/123')
        assert tt.can_handle('https://vm.tiktok.com/123')
        assert tt.can_handle('https://vt.tiktok.com/123')

    def test_instagram_downloader_detection(self):
        """Test that InstagramDownloader detects Instagram URLs"""
        ig = InstagramDownloader('/tmp')

        assert ig.can_handle('https://www.instagram.com/reel/123')
        assert ig.can_handle('https://www.instagram.com/tv/123')
        assert ig.can_handle('https://instagr.am/p/123')

    def test_generic_downloader_fallback(self):
        """Test that GenericDownloader handles any URL"""
        generic = GenericDownloader('/tmp')

        # GenericDownloader should handle anything (fallback)
        assert generic.can_handle('https://example.com/video')
        assert generic.can_handle('https://unknown-platform.com/video')


class TestDownloaderInitialization:
    """Test downloader initialization and configuration"""

    def test_downloader_quality_setting(self):
        """Test that downloaders respect quality settings"""
        yt = YouTubeDownloader('/tmp', quality='best[ext=mp4]/best')
        assert yt.quality == 'best[ext=mp4]/best'

        yt2 = YouTubeDownloader('/tmp', quality='worst')
        assert yt2.quality == 'worst'

    def test_downloader_directory_setting(self):
        """Test that downloaders use correct download directory"""
        yt = YouTubeDownloader('/custom/path')
        assert yt.download_dir == '/custom/path'


class TestIntegration:
    """Integration tests - these are manual testing examples"""

    @pytest.mark.skip(reason="Requires real YouTube URL and internet")
    async def test_youtube_download_real(self):
        """
        Real download test - uncomment and run to test actual downloading

        Note: This requires a real URL and internet connection
        It will take time to complete
        """
        import asyncio
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            yt = YouTubeDownloader(tmpdir)
            # Using a short, harmless video
            result = await yt.download('https://www.youtube.com/watch?v=dQw4w9WgXcQ')

            assert result is not None
            assert result.title is not None
            assert os.path.exists(result.file_path)
            assert os.path.getsize(result.file_path) > 0


def run_manual_tests():
    """
    Manual testing script - run this to test real downloads

    Usage:
        python tests/test_downloaders.py
    """
    import asyncio

    async def test_url(url: str):
        """Test downloading a single URL"""
        import tempfile

        print(f"\n📥 Testing URL: {url}")

        with tempfile.TemporaryDirectory() as tmpdir:
            # Find appropriate downloader
            downloaders = [
                YouTubeDownloader(tmpdir),
                TikTokDownloader(tmpdir),
                InstagramDownloader(tmpdir),
                GenericDownloader(tmpdir),
            ]

            downloader = None
            for dl in downloaders:
                if dl.can_handle(url):
                    downloader = dl
                    print(f"✓ Using {dl.__class__.__name__}")
                    break

            if not downloader:
                print("✗ No suitable downloader found")
                return

            try:
                print("⏳ Downloading...")
                result = await downloader.download(url)

                print(f"✓ Download successful!")
                print(f"  Title: {result.title}")
                print(f"  File: {result.file_path}")
                print(f"  Size: {result.size} bytes")
                if result.duration:
                    print(f"  Duration: {result.duration}s")

                # Cleanup
                await downloader.cleanup(result.file_path)
                print(f"✓ Cleaned up temporary file")

            except Exception as e:
                print(f"✗ Download failed: {e}")

    async def main():
        """Run manual tests"""
        test_urls = [
            # Add URLs here to test
            # 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
            # 'https://vm.tiktok.com/...',
            # 'https://www.instagram.com/reel/...',
        ]

        for url in test_urls:
            await test_url(url)

    print("📚 Video Downloader Test Suite")
    print("=" * 50)

    # Run unit tests
    print("\n🧪 Running unit tests...")
    pytest.main([__file__, '-v'])

    # Run manual tests if URLs are provided
    # Uncomment and add URLs above to test real downloads
    # asyncio.run(main())


if __name__ == '__main__':
    run_manual_tests()
