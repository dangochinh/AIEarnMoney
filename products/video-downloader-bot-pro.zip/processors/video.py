import os
import asyncio
import ffmpeg
from typing import Optional


class VideoProcessor:
    """Handle video processing tasks like watermark removal"""

    def __init__(self, enable_watermark_removal: bool = False):
        self.enable_watermark_removal = enable_watermark_removal

    async def remove_watermark(
        self,
        input_file: str,
        output_file: str,
        watermark_area: Optional[tuple] = None
    ) -> bool:
        """
        Remove watermark from video using FFmpeg.

        Args:
            input_file: Path to input video
            output_file: Path to output video
            watermark_area: Optional tuple of (x, y, width, height) for watermark position

        Returns:
            True if successful, False otherwise
        """
        if not self.enable_watermark_removal:
            return False

        try:
            # Run FFmpeg in a thread to avoid blocking
            return await asyncio.to_thread(
                self._remove_watermark_sync,
                input_file,
                output_file,
                watermark_area
            )
        except Exception as e:
            print(f"Error removing watermark: {e}")
            return False

    def _remove_watermark_sync(
        self,
        input_file: str,
        output_file: str,
        watermark_area: Optional[tuple] = None
    ) -> bool:
        """Synchronous watermark removal using FFmpeg"""
        try:
            # If specific area is given, use crop filter
            if watermark_area:
                x, y, w, h = watermark_area
                # Use crop filter to remove watermark area
                stream = ffmpeg.input(input_file)
                stream = ffmpeg.filter(stream, 'crop', w, h, x, y)
                stream = ffmpeg.output(stream, output_file, codec='copy')
                ffmpeg.run(stream, capture_stdout=True, capture_stderr=True, overwrite_output=True)
            else:
                # Generic watermark removal - re-encode video (may reduce quality)
                # This is a basic approach; advanced watermark removal is complex
                stream = ffmpeg.input(input_file)
                stream = ffmpeg.output(stream, output_file, codec='libx264', preset='medium')
                ffmpeg.run(stream, capture_stdout=True, capture_stderr=True, overwrite_output=True)

            return os.path.exists(output_file) and os.path.getsize(output_file) > 0
        except ffmpeg.Error as e:
            print(f"FFmpeg error: {e.stderr.decode() if e.stderr else str(e)}")
            return False
        except Exception as e:
            print(f"Error in watermark removal: {e}")
            return False

    async def get_video_info(self, file_path: str) -> dict:
        """Get video metadata using FFmpeg"""
        try:
            return await asyncio.to_thread(self._get_video_info_sync, file_path)
        except Exception as e:
            print(f"Error getting video info: {e}")
            return {}

    def _get_video_info_sync(self, file_path: str) -> dict:
        """Synchronous video info retrieval"""
        try:
            probe = ffmpeg.probe(file_path)
            video_info = next(
                (stream for stream in probe['streams'] if stream['codec_type'] == 'video'),
                None
            )

            if video_info:
                return {
                    'duration': float(probe['format'].get('duration', 0)),
                    'width': video_info.get('width'),
                    'height': video_info.get('height'),
                    'codec': video_info.get('codec_name'),
                    'fps': eval(video_info.get('r_frame_rate', '30/1')),
                }
            return {}
        except Exception as e:
            print(f"Error probing video: {e}")
            return {}
