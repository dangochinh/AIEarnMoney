import os
import asyncio
from pathlib import Path
from datetime import datetime, timedelta
import config


async def cleanup_old_files(hours: int = None) -> None:
    """Remove files older than specified hours"""
    if hours is None:
        hours = config.CLEANUP_HOURS

    try:
        download_dir = Path(config.DOWNLOAD_DIR)
        if not download_dir.exists():
            return

        cutoff_time = datetime.now() - timedelta(hours=hours)

        for file_path in download_dir.glob('*'):
            if file_path.is_file():
                file_time = datetime.fromtimestamp(file_path.stat().st_mtime)
                if file_time < cutoff_time:
                    file_path.unlink()
    except Exception as e:
        print(f"Error during cleanup: {e}")


def format_file_size(size_bytes: int) -> str:
    """Convert bytes to human-readable format"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"


def format_duration(seconds: int) -> str:
    """Convert seconds to human-readable duration"""
    if seconds is None:
        return "Unknown"

    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60

    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    elif minutes > 0:
        return f"{minutes}:{secs:02d}"
    else:
        return f"{secs}s"


async def check_disk_space(required_mb: int = 100) -> bool:
    """Check if there's enough disk space"""
    try:
        stat = os.statvfs(config.DOWNLOAD_DIR)
        available_mb = (stat.f_bavail * stat.f_frsize) / (1024 * 1024)
        return available_mb > required_mb
    except Exception as e:
        print(f"Error checking disk space: {e}")
        return False


async def is_file_too_large(file_path: str) -> bool:
    """Check if file exceeds max size limit"""
    try:
        file_size = os.path.getsize(file_path)
        return file_size > config.MAX_FILE_SIZE
    except Exception:
        return True
