import { Player } from '../types';

type DrawStage = 'SAFE_INIT' | 'WAITING_PUSH' | 'NATURAL_FINISH';

export interface DrawResult {
    number: number;
    stage: DrawStage;
    totalDrawn: number;
}

/**
 * LotoController - Thuật toán Điều tiết Loto Kịch tính
 *
 * 3 giai đoạn:
 *  1. SAFE_INIT     : Bốc K số đầu tiên (K ∈ [10,20]) an toàn, chặn Bingo/Chờ sớm
 *  2. WAITING_PUSH  : Đẩy tất cả người chơi vào thế chờ (≥1 hàng 4/5)
 *  3. NATURAL_FINISH: Xổ random 100%
 */
export class LotoController {
    private players: Player[];
    private drawnNumbers: Set<number>;
    private allNumbers: number[];
    public currentStage: DrawStage;
    public k_threshold: number;
    private lastWinnerIds: string[];
    private isSpecialRound: boolean;
    private streakCounts: Record<string, number>;
    private cappedPlayerIds: string[];

    constructor(
        players: Player[],
        streakCounts: Record<string, number> = {},
        lastWinnerIds: string[] = [],
        isSpecialRound: boolean = false,
        cappedPlayerIds: string[] = []
    ) {
        this.players = players;
        this.drawnNumbers = new Set();
        this.allNumbers = Array.from({ length: 90 }, (_, i) => i + 1);
        this.currentStage = 'SAFE_INIT';
        this.k_threshold = Math.floor(Math.random() * 11) + 15; // K ∈ [15, 25]
        this.streakCounts = streakCounts;
        this.lastWinnerIds = lastWinnerIds;
        this.isSpecialRound = isSpecialRound;
        this.cappedPlayerIds = cappedPlayerIds;
    }

    /** Kiểm tra số num có làm người bị giới hạn đạt Bingo không */
    private isCappedBingo(num: number): boolean {
        if (!this.cappedPlayerIds || this.cappedPlayerIds.length === 0) return false;

        for (const cappedId of this.cappedPlayerIds) {
            const player = this.players.find(p => p.id === cappedId);
            if (!player || !player.tickets) continue;

            for (const ticket of player.tickets) {
                for (const row of ticket) {
                    if (row.includes(num)) {
                        const status = this.getRowStatus(row);
                        if (status.hits === 4) return true; // Sắp bingo và bốc trúng số cuối -> Bingo
                    }
                }
            }
        }
        return false;
    }

    /** Đếm số hit trong một hàng */
    private getRowStatus(row: number[]): { hits: number; total: number } {
        const nonZero = row.filter(num => num !== 0);
        const hits = nonZero.filter(num => this.drawnNumbers.has(num)).length;
        return { hits, total: nonZero.length };
    }

    /** Kiểm tra TẤT CẢ người chơi đã có ít nhất 1 hàng đạt 4/5 */
    private checkAllWaiting(): boolean {
        return this.players.every(player => {
            if (!player.tickets || !Array.isArray(player.tickets)) return false;
            return player.tickets.some(ticket =>
                ticket.some(row => this.getRowStatus(row).hits >= 4)
            );
        });
    }

    /**
     * Bốc số tiếp theo (logic ngầm)
     * Trả về null nếu hết số
     */
    drawNextNumber(): DrawResult | null {
        const remainingNumbers = this.allNumbers.filter(n => !this.drawnNumbers.has(n));
        if (remainingNumbers.length === 0) return null;

        // Stage Transition
        if (this.currentStage === 'SAFE_INIT' && this.drawnNumbers.size >= this.k_threshold) {
            this.currentStage = 'WAITING_PUSH';
        }
        if (this.currentStage === 'WAITING_PUSH' && this.checkAllWaiting()) {
            this.currentStage = 'NATURAL_FINISH';
        }

        // Lọc bỏ những số làm người chơi đã đạt giới hạn bị Bingo
        let filteredRemaining = remainingNumbers.filter(n => !this.isCappedBingo(n));
        if (filteredRemaining.length === 0) {
            filteredRemaining = remainingNumbers; // Nếu không còn số nào khác, đành bốc đại
        }

        let candidate: number | undefined;

        if (this.currentStage === 'SAFE_INIT') {
            candidate = this.drawSafeInit(filteredRemaining);
        } else if (this.currentStage === 'WAITING_PUSH') {
            candidate = this.drawWaitingPush(filteredRemaining);
        } else {
            candidate = this.drawNaturalFinish(filteredRemaining);
        }

        if (candidate === undefined || candidate === null) {
            candidate = filteredRemaining[0];
        }

        this.drawnNumbers.add(candidate);
        return {
            number: candidate,
            stage: this.currentStage,
            totalDrawn: this.drawnNumbers.size
        };
    }

    /**
     * GIAI ĐOẠN 3: Tự nhiên nhưng có kiểm soát
     * 1. No one left behind: Nếu ván đặc biệt, ưu tiên người thắng ít nhất.
     * 2. Hạn chế thắng liên tục: Ưu tiên thấp cho người vừa thắng ván trước.
     */
    private drawNaturalFinish(remaining: number[]): number {
        // 1. Kiểm tra ván đặc biệt: "No one left behind"
        if (this.isSpecialRound) {
            return this.drawFavorLuckless(remaining);
        }

        // 2. Kiểm tra hạn chế thắng liên tiếp
        if (this.lastWinnerIds.length > 0) {
            return this.drawAvoidRecentWinners(remaining);
        }

        // Mặc định: Ngẫu nhiên
        return remaining[Math.floor(Math.random() * remaining.length)];
    }

    /** Ưu tiên người chơi có số ván chưa bingo cao nhất */
    private drawFavorLuckless(remaining: number[]): number {
        const maxStreak = Math.max(...this.players.map(p => this.streakCounts[p.id] || 0));
        const lucklessPlayers = this.players.filter(p => (this.streakCounts[p.id] || 0) === maxStreak);

        const targetPool: number[] = [];

        // Ưu tiên 1: Người chơi đang chờ 4/5 -> Bốc phát thắng luôn
        for (const player of lucklessPlayers) {
            if (!player.tickets) continue;
            for (const ticket of player.tickets) {
                for (const row of ticket) {
                    const { hits } = this.getRowStatus(row);
                    if (hits === 4) {
                        const missing = row.filter(n => n !== 0 && !this.drawnNumbers.has(n));
                        missing.forEach(n => { if (remaining.includes(n)) targetPool.push(n); });
                    }
                }
            }
        }

        if (targetPool.length > 0) {
            return targetPool[Math.floor(Math.random() * targetPool.length)];
        }

        // Ưu tiên 2: Người chơi đang 3/5 -> Tiến lên 4/5
        for (const player of lucklessPlayers) {
            if (!player.tickets) continue;
            for (const ticket of player.tickets) {
                for (const row of ticket) {
                    const { hits } = this.getRowStatus(row);
                    if (hits === 3) {
                        const missing = row.filter(n => n !== 0 && !this.drawnNumbers.has(n));
                        missing.forEach(n => { if (remaining.includes(n)) targetPool.push(n); });
                    }
                }
            }
        }

        if (targetPool.length > 0) {
            return targetPool[Math.floor(Math.random() * targetPool.length)];
        }

        return remaining[Math.floor(Math.random() * remaining.length)];
    }

    /** Tránh bốc số khiến người thắng ván trước thắng tiếp */
    private drawAvoidRecentWinners(remaining: number[]): number {
        const pool = [...remaining];
        // Xáo trộn sơ bộ
        for (let i = pool.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [pool[i], pool[j]] = [pool[j], pool[i]];
        }

        for (const val of pool) {
            let causesRecentWinnerBingo = false;
            for (const winnerId of this.lastWinnerIds) {
                const player = this.players.find(p => p.id === winnerId);
                if (!player || !player.tickets) continue;
                for (const ticket of player.tickets) {
                    for (const row of ticket) {
                        const { hits } = this.getRowStatus(row);
                        if (hits === 4 && row.includes(val)) {
                            causesRecentWinnerBingo = true;
                            break;
                        }
                    }
                    if (causesRecentWinnerBingo) break;
                }
                if (causesRecentWinnerBingo) break;
            }

            if (!causesRecentWinnerBingo) return val;
        }

        return pool[0]; // Fallback
    }

    /**
     * GIAI ĐOẠN 1: Bốc số an toàn
     * - Trước số K: Chặn cả 4/5 (Chờ) và 5/5 (Bingo)
     * Vi phạm → hủy và bốc lại ngầm
     */
    private drawSafeInit(remaining: number[]): number {
        const pool = [...remaining];

        while (pool.length > 0) {
            const idx = Math.floor(Math.random() * pool.length);
            const val = pool.splice(idx, 1)[0];
            let isViolated = false;

            for (const player of this.players) {
                if (!player.tickets) continue;
                for (const ticket of player.tickets) {
                    for (const row of ticket) {
                        const { hits } = this.getRowStatus(row);
                        const isInRow = row.includes(val);
                        if (!isInRow) continue;

                        // Chặn cả 4/5 (Chờ) và 5/5 (Bingo)
                        if (hits >= 3) { isViolated = true; break; }
                    }
                    if (isViolated) break;
                }
                if (isViolated) break;
            }

            if (!isViolated) return val;
        }

        return remaining[0]; // Fallback
    }

    /**
     * GIAI ĐOẠN 2: Đẩy mọi người vào thế chờ (4/5)
     * Bắt buộc chạy đến khi 100% có ≥1 hàng 4/5
     */
    private drawWaitingPush(remaining: number[]): number {
        // Nếu là ván cứu, ưu tiên tuyệt đối đẩy người "đen" nhất lên 4/5 trước
        if (this.isSpecialRound) {
            const maxStreak = Math.max(...this.players.map(p => this.streakCounts[p.id] || 0));
            const lucklessNotWaiting = this.players.filter(p => {
                const isNotWaiting = !p.tickets?.some(t => t.some(r => this.getRowStatus(r).hits >= 4));
                return isNotWaiting && (this.streakCounts[p.id] || 0) === maxStreak;
            });

            if (lucklessNotWaiting.length > 0) {
                const lpTargetPool: number[] = [];
                for (const player of lucklessNotWaiting) {
                    if (!player.tickets) continue;
                    for (const ticket of player.tickets) {
                        for (const row of ticket) {
                            const { hits } = this.getRowStatus(row);
                            if (hits === 3 || hits === 2) {
                                const missing = row.filter(n => n !== 0 && !this.drawnNumbers.has(n));
                                missing.forEach(n => { if (remaining.includes(n)) lpTargetPool.push(n); });
                            }
                        }
                    }
                }
                if (lpTargetPool.length > 0) {
                    return lpTargetPool[Math.floor(Math.random() * lpTargetPool.length)];
                }
            }
        }

        const notWaitingPlayers = this.players.filter(player => {
            if (!player.tickets) return false;
            return !player.tickets.some(ticket =>
                ticket.some(row => this.getRowStatus(row).hits >= 4)
            );
        });

        const targetPool: number[] = [];

        // Ưu tiên 1: rows 3/5 → tìm số để lên 4/5
        for (const player of notWaitingPlayers) {
            if (!player.tickets) continue;
            for (const ticket of player.tickets) {
                for (const row of ticket) {
                    const { hits } = this.getRowStatus(row);
                    if (hits === 3) {
                        const missing = row.filter(n => n !== 0 && !this.drawnNumbers.has(n));
                        missing.forEach(n => { if (remaining.includes(n)) targetPool.push(n); });
                    }
                }
            }
        }

        // Ưu tiên 2: rows 2/5
        if (targetPool.length === 0) {
            for (const player of notWaitingPlayers) {
                if (!player.tickets) continue;
                for (const ticket of player.tickets) {
                    for (const row of ticket) {
                        const { hits } = this.getRowStatus(row);
                        if (hits === 2) {
                            const missing = row.filter(n => n !== 0 && !this.drawnNumbers.has(n));
                            missing.forEach(n => { if (remaining.includes(n)) targetPool.push(n); });
                        }
                    }
                }
            }
        }

        if (targetPool.length > 0) {
            const frequency: Record<number, number> = {};
            targetPool.forEach(n => { frequency[n] = (frequency[n] || 0) + 1; });
            const bestNumber = Object.keys(frequency)
                .sort((a, b) => frequency[Number(b)] - frequency[Number(a)])[0];
            return parseInt(bestNumber);
        }

        return remaining[Math.floor(Math.random() * remaining.length)];
    }
}
